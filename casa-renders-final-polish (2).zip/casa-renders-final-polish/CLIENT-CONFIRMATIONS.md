# Client Confirmations Before Launch

Use this as the final pre-launch checklist.

## Identity and leadership

- [ ] Confirm whether the structural engineer’s name is **Jai Sirsiya** or **Jal Sirsiya**.
- [ ] Confirm Vandana Bhojak’s preferred public designation.
- [ ] Approve the short leadership descriptions.
- [ ] Add professional team photographs later, if available.

## Contact details

- [ ] Confirm `casarenders09@gmail.com` is the official email address.
- [ ] Confirm both phone numbers.
- [ ] Confirm whether the office is **GF** or **LGF**.
- [ ] Confirm office hours.
- [ ] Confirm the Google Map points to the correct entrance/location.

## Experience and organisation marks

- [ ] Confirm every organisation name shown in Professional Exposure.
- [ ] Confirm permission to display each organisation’s mark/logo.
- [ ] Replace reconstructed SVG marks with official approved assets when available.
- [ ] Retain the existing disclaimer unless the client provides a different approved statement.

## Portfolio and imagery

- [ ] Confirm the client understands that current interior photographs are labelled as concept inspiration, not completed work.
- [ ] Replace concept images with approved project renders as the real portfolio grows.
- [ ] Approve the Café / Restaurant and Full Home categories.

## Social and content

- [ ] Confirm Instagram URL.
- [ ] Confirm Facebook URL.
- [ ] Confirm YouTube channel URL.
- [ ] Add YouTube video IDs in `src/config/site.ts` if individual videos should be embedded.

## Legal and commercial

- [ ] Have Privacy Policy and Terms reviewed by qualified legal counsel.
- [ ] Confirm package descriptions and all service claims.
- [ ] Confirm whether VisiCore AI may retain the footer signature and link.
