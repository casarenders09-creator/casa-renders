# Casa Renders — Final Art-Direction & Conversion Polish

This build is based on the exact refined ZIP supplied after the desktop audit.
It is a consolidated project, not another phase patch.

## Changes in this build

- Hero story shortened and retimed; the final message remains visible until release.
- Desktop navigation reduced to five clear destinations and enlarged.
- About now focuses on philosophy; all approved legacy facts are retained in Experience.
- Professional exposure combines 1988, 2018, Delhi NCR and India-wide support with the organisation wall.
- Detailed services show six core capabilities first while retaining every approved service in an expandable index.
- Every selected-work image carries an explicit Concept visualisation label.
- Package CTAs preselect the exact package in the enquiry form.
- Service CTAs preselect the relevant service in the enquiry form.
- WhatsApp assistance is smaller and automatically hides over the enquiry, contact and footer sections.
- Supporting typography and mobile behaviour have been refined.
- No client-approved section was removed.

## Run

```powershell
npm install
npm run dev:clean
```

Validate from a second terminal:

```powershell
npm run lint
npx tsc --noEmit
npm run build
```

## Important

The project ZIP is intentionally packaged with `package.json` at its top level. You do not need to enter a second nested project folder after extracting it.
