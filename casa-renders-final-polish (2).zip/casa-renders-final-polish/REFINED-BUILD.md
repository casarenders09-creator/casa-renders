# Casa Renders — Refined Edition

This package is a consolidated refinement of the current Casa Renders build. It is not intended to be layered on top of the earlier Phase 1–5 ZIP files.

## Main refinements

- Shorter, smoother cinematic hero with a controlled exit before the sticky frame releases
- Improved hero typography and final-stage CTA timing
- Editorial About layout with readable body copy and a deliberate experience timeline
- Two-row professional-exposure logo wall with soft edge fades
- Larger asymmetric Selected Work gallery
- Softer industry ticker edges and calmer animation pacing
- Reduced mid-page whitespace across Why, Process and Packages
- Typographic leadership profiles that do not pretend placeholder initials are photographs
- Stronger Casa Renders TV feature and editorial content formats
- Two-step progressive estimate form that is easier to complete
- Earlier section reveals to prevent headings appearing clipped during fast scrolling
- Responsive refinements for tablet and mobile layouts

## Install

From the project folder:

```powershell
npm install
npm run dev:clean
```

Then validate:

```powershell
npm run lint
npx tsc --noEmit
npm run build
```

## Important

- Do not paste the older Phase ZIP files over this package.
- The current concept imagery is intentionally labelled as visual inspiration rather than completed client work.
- Add an authentic Casa Renders hero film later at the configured paths in `public/videos` without rebuilding the hero.
