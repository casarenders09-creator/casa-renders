import { SiteShell } from "@/components/layout/SiteShell";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppFab } from "@/components/layout/WhatsAppFab";
import { CinematicPolish } from "@/components/layout/CinematicPolish";
import { HeroSection } from "@/components/sections/HeroSection";
import { TrustStrip } from "@/components/sections/TrustStrip";
import { AboutSection } from "@/components/sections/AboutSection";
import { ProfessionalExperienceSection } from "@/components/sections/ProfessionalExperienceSection";
import { ServicePillars } from "@/components/sections/ServicePillars";
import { SelectedWorkSection } from "@/components/sections/SelectedWorkSection";
import { EndToEndSection } from "@/components/sections/EndToEndSection";
import { ServicesGrid } from "@/components/sections/ServicesGrid";
import { IndustriesSection } from "@/components/sections/IndustriesSection";
import { DesignIdeasSection } from "@/components/sections/DesignIdeasSection";
import { EstimateSection } from "@/components/sections/EstimateSection";
import { WhyChooseSection } from "@/components/sections/WhyChooseSection";
import { HowItWorksSection } from "@/components/sections/HowItWorksSection";
import { PackagesSection } from "@/components/sections/PackagesSection";
import { DirectorsSection } from "@/components/sections/DirectorsSection";
import { CasaRendersTVSection } from "@/components/sections/CasaRendersTVSection";
import { QuoteFormSection } from "@/components/sections/QuoteFormSection";
import { ContactSection } from "@/components/sections/ContactSection";

export default function HomePage() {
  return (
    <SiteShell>
      <CinematicPolish />
      <Header />
      <main id="main-content">
        <HeroSection />
        <TrustStrip />
        <AboutSection />
        <ProfessionalExperienceSection />
        <ServicePillars />
        <SelectedWorkSection />
        <EndToEndSection />
        <ServicesGrid />
        <IndustriesSection />
        <DesignIdeasSection />
        <EstimateSection />
        <WhyChooseSection />
        <HowItWorksSection />
        <PackagesSection />
        <DirectorsSection />
        <CasaRendersTVSection />
        <QuoteFormSection />
        <ContactSection />
      </main>
      <Footer />
      <WhatsAppFab />
    </SiteShell>
  );
}
