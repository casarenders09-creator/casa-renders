import { endToEndSolutions } from "@/content/visuals";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { Container } from "@/components/ui/Container";

export function EndToEndSection() {
  return (
    <AnimatedSection className="end-to-end section-blueprint">
      <Container>
        <div className="end-to-end__layout">
          <div className="end-to-end__intro">
            <p className="section-eyebrow">End-to-end solutions</p>
            <h2 className="display-heading">
              One design language,
              <br />
              from the room to the <em>building.</em>
            </h2>
            <p>
              Focus on one space or coordinate the complete experience. Interior decisions,
              exterior expression and structural inputs can be considered within one connected
              project conversation.
            </p>
            <a href="#quote" className="text-arrow-link">
              Discuss your project <span aria-hidden="true">↗</span>
            </a>
          </div>

          <div className="end-to-end__list">
            {endToEndSolutions.map((item) => (
              <article key={item.id}>
                <span>{item.number}</span>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </Container>
    </AnimatedSection>
  );
}
