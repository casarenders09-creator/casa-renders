import { processSteps } from "@/content/process";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { Container } from "@/components/ui/Container";

export function HowItWorksSection() {
  return (
    <AnimatedSection id="how-it-works" className="process-section section-deep">
      <Container>
        <div className="process-section__layout">
          <div className="process-section__intro">
            <p className="section-eyebrow">Our process</p>
            <h2>
              From first conversation
              <br />
              to a space that feels <em>resolved.</em>
            </h2>
            <p>
              A transparent sequence keeps design decisions, technical inputs and site coordination moving in the same direction.
            </p>
          </div>

          <ol className="process-section__steps">
            {processSteps.map((step) => (
              <li key={step.step}>
                <span>{String(step.step).padStart(2, "0")}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </Container>
    </AnimatedSection>
  );
}
