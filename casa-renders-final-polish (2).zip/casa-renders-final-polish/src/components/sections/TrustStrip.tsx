import { Container } from "@/components/ui/Container";

const disciplines = [
  "Interior design",
  "Structural engineering",
  "3D visualisation",
  "Project coordination",
  "Residential · Commercial · Hospitality",
];

export function TrustStrip() {
  return (
    <section className="discipline-strip" aria-label="Casa Renders capabilities">
      <Container>
        <div>
          {disciplines.map((item) => (
            <span key={item}>{item}</span>
          ))}
        </div>
      </Container>
    </section>
  );
}
