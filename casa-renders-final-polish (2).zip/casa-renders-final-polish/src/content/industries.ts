export const industries = [
  { id: "residential", label: "Residential homes" },
  { id: "apartments", label: "Apartments" },
  { id: "offices", label: "Offices" },
  { id: "retail", label: "Retail stores" },
  { id: "showrooms", label: "Showrooms" },
  { id: "clinics", label: "Clinics" },
  { id: "salons", label: "Salons" },
  { id: "restaurants", label: "Restaurants" },
  { id: "cafes", label: "Cafés" },
  { id: "hospitality", label: "Hospitality spaces" },
  { id: "commercial", label: "Commercial properties" },
  { id: "industrial", label: "Selected industrial projects" },
] as const;

// TODO: Enable only after the client confirms the exact relationship and permission to publish the organisation names.
export const professionalExperienceOrganisations = [
  "IOCL",
  "EIL",
  "MECON",
  "IGGL",
  "Megha Engineering",
  "HPPCL",
  "Gaurs Group",
  "TAG Tarun Art Gallery",
  "MCD",
  "Kautaliya Infratech",
  "Prestige Group",
  "Teroneng",
  "Apex Builder",
] as const;

export const professionalExperienceHeading =
  "Professional Exposure Across Diverse Projects and Organisations";
