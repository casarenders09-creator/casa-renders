export const leadership = [
  {
    id: "jai-sirsiya",
    name: "Jai Sirsiya",
    designation: "Structural Engineer",
    phone: "8800273706",
  },
  {
    id: "vandana-bhojak",
    name: "Vandana Bhojak",
    designation: "Interior Designer",
    phone: "8826387424",
  },
] as const;
