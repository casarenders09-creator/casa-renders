export const primaryNavigationItems = [
  { label: "Studio", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Work", href: "#work" },
  { label: "Design Ideas", href: "#design-ideas" },
  { label: "Contact", href: "#contact" },
] as const;

export const navigationItems = [
  { label: "Studio", href: "#about" },
  { label: "Experience", href: "#experience" },
  { label: "Services", href: "#services" },
  { label: "Work", href: "#work" },
  { label: "Design Ideas", href: "#design-ideas" },
  { label: "Process", href: "#how-it-works" },
  { label: "Packages", href: "#packages" },
  { label: "Contact", href: "#contact" },
] as const;

export const footerQuickLinks = [
  { label: "About the studio", href: "#about" },
  { label: "Professional exposure", href: "#experience" },
  { label: "Selected visual studies", href: "#work" },
  { label: "Design ideas", href: "#design-ideas" },
  { label: "Get an estimate", href: "#quote" },
] as const;

export const footerServiceLinks = [
  { label: "Interior Design", href: "#services" },
  { label: "Structural Engineering", href: "#services" },
  { label: "3D Visualisation", href: "#services" },
  { label: "Space Planning", href: "#services" },
  { label: "Project Coordination", href: "#services" },
] as const;
