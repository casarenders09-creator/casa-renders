export const processSteps = [
  {
    step: 1,
    title: "Share project requirements",
    description: "Tell us about your space, goals, timeline and budget expectations.",
  },
  {
    step: 2,
    title: "Initial consultation",
    description: "We discuss scope, priorities and the most suitable service package.",
  },
  {
    step: 3,
    title: "Site or drawing assessment",
    description: "We review site conditions, measurements or available architectural inputs.",
  },
  {
    step: 4,
    title: "Concept and space planning",
    description: "Layout, circulation and design direction are developed and refined.",
  },
  {
    step: 5,
    title: "Design and 3D visualization",
    description: "Detailed design, materials and photorealistic renders where included.",
  },
  {
    step: 6,
    title: "Technical and budget finalisation",
    description: "Scope, deliverables and budget alignment are confirmed before execution.",
  },
  {
    step: 7,
    title: "Execution or coordination",
    description: "Site visits, vendor coordination and design compliance as per package.",
  },
  {
    step: 8,
    title: "Review and handover",
    description: "Final review, styling guidance and project closure support.",
  },
] as const;
